from rest_framework import viewsets, permissions, generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from staff.views import *
from staff.serializers import *
from staff.method_tab import *
from rest_framework.generics import get_object_or_404
from django.http import QueryDict

class user_api(APIView) :
    def get(self, request) :
        return Response(status= status.HTTP_200_OK)
    
    # user 생성 
    def post(self, request) :
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid() :
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(status = status.HTTP_400_BAD_REQUEST)     
    
class hospital_api(APIView) :
    
    # 모든 병원 목록 반환
    def get(self, request) :
        hosiptial_list = Hospital_List.objects.all()
        serializer = HosiptialSerializer(hosiptial_list, many = True)
        return Response(serializer.data, status= status.HTTP_200_OK)
    
class hospital_search(APIView) :
    # # 검색된 병원 목록 반환
    def get(self, request, text) :
        hosiptial_list = Hospital_List.objects.filter(hospital_name__contains=text)
        serializer = HosiptialSerializer(hosiptial_list, many = True)
        return Response(serializer.data, status= status.HTTP_200_OK)
    
class docs_api(APIView) :
    # 진료중인 의사 목록 반환
    def get(self, request) :
        hosiptial_list = Hospital_List.objects.filter(hospital_status = True)
        result = []
        for i in hosiptial_list :
            doc_list = Doctor.objects.filter(doctor_status = True, Hospital_ID = i.Hospital_ID)
            result += doc_list
        
        serializer = DoctorSerializer(result, many = True)
        return Response(serializer.data, status= status.HTTP_200_OK)
    
class rsvs_api(APIView) :
    # 유저의 모든 예약 정보 반환
    def get(self, request, user_account) :
        
        user = get_object_or_404(Users, user_account = user_account)
        rsv = Reservation.objects.filter(User_ID = user.User_ID)
        
        hos = Hospital_List.objects.all()
        data = []
        
        for j in hos :
            doc = list(Doctor.objects.filter(Hospital_ID_id = j.Hospital_ID))
            
            for i in doc :
                rsv = []
                a = list(Reservation.objects.filter(Doctor_ID = i.Doctor_ID ,reservation_status = 'waiting'))
                b = list(Reservation_non.objects.filter(Doctor_ID = i.Doctor_ID ,reservation_status = 'waiting'))
                rsv = a+b
                rsv = sorted(rsv, key=lambda x : x.reservation_date)
                
                if rsv:
                    for idx, k in enumerate(rsv):
                        if k.User_ID_id == user.User_ID:
                            data.append({'Hospital':j.hospital_name, 'doctor':i.doctor_name, 'Q':idx+1, 'RsvID': k.Reservation_ID})
                data.sort(key = lambda x: x['Q'])
          
        return Response(data, status= status.HTTP_200_OK)

    
    # 신규 예약 등록
    def post(self, request, user_account) :
        user = Users.objects.get(user_account = user_account)
        doctor = Doctor.objects.get(Doctor_ID = request.data['Doctor_ID'])
        ordinary_dict = {'Doctor_ID': request.data['Doctor_ID'], 'User_ID': user.User_ID, 'reservation_name' : user.user_name, 'reservation_status':'waiting'}
        query_dict = QueryDict('', mutable=True)
        query_dict.update(ordinary_dict)
        
        serializer = ReservationSerializer(data=query_dict)
        if serializer.is_valid() :
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(status = status.HTTP_400_BAD_REQUEST)
    
    
class rsv_api(APIView) :
    
    # 지정된 예약 건 반환
    def get(self, request, rsv_id) :
        rsv = get_object_or_404(Reservation, Reservation_ID= rsv_id)
        serializer = ReservationSerializer(rsv)
        return Response(serializer.data, status= status.HTTP_200_OK)
    
    # 예약 취소
    def post(self, request, rsv_id) :
        rsv = get_object_or_404(Reservation, Reservation_ID= rsv_id)
        rsv.reservation_status = 'cancel'
        rsv.save()
        serializer = ReservationSerializer(rsv)
        return Response(serializer.data, status=status.HTTP_200_OK)
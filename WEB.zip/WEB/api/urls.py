from django.urls import path, include
from .views import *

app_name = 'api'
urlpatterns = [
    path('rsvs/<str:user_account>/', rsvs_api.as_view()),
    path('rsv/<int:rsv_id>/', rsv_api.as_view()),
    path('user/', user_api.as_view()),
    path('hospital_api/', hospital_api.as_view()),
    path('hospital_search/<str:text>/', hospital_search.as_view()),
    path('docs_api/', docs_api.as_view()),
]
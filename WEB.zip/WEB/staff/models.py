from django.db import models

# 앱 이용 고객 정보
class Users(models.Model) :
    User_ID  = models.AutoField(primary_key=True)
    user_name = models.CharField(max_length=50)
    user_account = models.CharField(max_length=50, unique=True) 
    user_tel = models.CharField(max_length=50, unique=True) 
    user_pwd = models.CharField(max_length=50) 
    user_rnn = models.CharField(max_length=50, unique=True) 
    user_addr = models.CharField(max_length=50) 
    
    def __str__(self):
        return self.user_name
# 앱 이용 고객 자녀 정보
class Children(models.Model) :
    Children_ID = models.AutoField(primary_key=True)
    User_ID = models.ForeignKey(Users, on_delete=models.CASCADE)
    children_name = models.CharField(max_length=50)

# 진료과 정보
class Department(models.Model) :
    Dept_ID = models.AutoField(primary_key=True)
    dept_name = models.CharField(max_length=50) 
    def __str__(self):
        return self.dept_name

# 병원 정보
class Hospital_List(models.Model) :
    Hospital_ID = models.AutoField(primary_key=True) 
    Dept_ID = models.ForeignKey(Department, on_delete=models.CASCADE)
    hospital_name = models.CharField(max_length=50) 
    hospital_status = models.BooleanField(default=False)
    lat = models.FloatField(max_length=50) 
    lng = models.FloatField(max_length=50)
    def __str__(self):
        return self.hospital_name
    
# 병원용 마스터 계정 정보
class Staff(models.Model) :
    Staff_ID = models.AutoField(primary_key=True)
    Hospital_ID = models.OneToOneField(Hospital_List, on_delete=models.CASCADE, related_name='my_related')
    staff_name = models.CharField(max_length=50)
    staff_account = models.CharField(max_length=50, unique=True)
    staff_pwd = models.CharField(max_length=50)     
    def __str__(self):
        return self.staff_name
    
# 의사 정보
class Doctor(models.Model) :
    Doctor_ID = models.AutoField(primary_key=True)
    Hospital_ID = models.ForeignKey(Hospital_List, on_delete=models.CASCADE)
    Dept_ID = models.ForeignKey(Department, on_delete=models.CASCADE)
    doctor_name = models.CharField(max_length=50) 
    doctor_content = models.CharField(max_length=100) 
    doctor_gender = models.BooleanField(default= False) 
    doctor_status = models.BooleanField(default = False)
    def __str__(self):
        return self.doctor_name

# 회원 예약 정보
class Reservation(models.Model) :
    Reservation_ID = models.AutoField(primary_key=True)
    User_ID = models.ForeignKey(Users, on_delete=models.CASCADE)
    Doctor_ID = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    reservation_name = models.CharField(max_length= 50)
    reservation_status = models.CharField(max_length=10)
    reservation_date = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.reservation_name

# 비회원 예약 정보
class Reservation_non(models.Model) :
    Reservation_ID = models.AutoField(primary_key=True)
    Doctor_ID = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    User_ID_id = models.IntegerField(default=-1)
    reservation_name = models.CharField(max_length= 50)
    reservation_status = models.CharField(max_length=10)
    reservation_date = models.DateTimeField(auto_now=True)
    user_tel = models.CharField(max_length=50)
    user_rnn = models.CharField(max_length=50)     
    user_addr = models.CharField(max_length=50)  
    def __str__(self):
        return self.reservation_name
    
# M2E 포인트 정보
class M2E(models.Model) :
    M2E_ID = models.AutoField(primary_key=True)
    User_ID = models.OneToOneField(Users, on_delete=models.CASCADE)
    points = models.IntegerField()
    rewards = models.CharField(max_length= 50)

# 메시지 호출 정보
class Alarm(models.Model) :
    Alarm_ID = models.AutoField(primary_key=True)
    Reservation_ID = models.ForeignKey(Reservation, on_delete=models.CASCADE)
    alarm_content = models.CharField(max_length= 100)
    alarm_date = models.DateTimeField()
    
# M2E 적립 내역
class Record(models.Model) :
    Record_ID = models.AutoField(primary_key=True)
    M2E_ID = models.ForeignKey(M2E, on_delete=models.CASCADE)
    date = models.DateTimeField()
    point = models.IntegerField()
    record_name = models.CharField(max_length=50)

from django.contrib import admin
from django.urls import path, include
from .import views
app_name = 'staff_app'
urlpatterns = [
    # web
    path('', views.login, name = 'login'),
    path('logout/', views.logout, name = 'logout'),
    path('modify/', views.modify_member_info, name = 'modify'),
    path('table/', views.table_all, name = 'table_all'),
    path('table/<int:dk>', views.table_detail, name='table_detail'),
    path('update/<int:dk>', views.update, name='update'),
    path('update_2/<int:dk>', views.update_2, name='update_2'),
    path('cancel/<int:rsv_id>', views.cancel, name='cancel'),
    path('cancel_non/<int:rsv_id>', views.cancel_non, name='cancel_non'),
    path('detail/<int:rsv_id>', views.detail, name='detail'),
    path('detail/<int:dk>/<int:rsv_id>', views.detail_2, name='detail_2'),
    path('detail_non/<int:rsv_id>', views.detail_non, name='detail_non'),
    path('detail_non/<int:dk>/<int:rsv_id>', views.detail_non_2, name='detail_non_2'),
    path('start/', views.start, name='start'),
    path('management/', views.management, name='management'),
    path('add/', views.add_doc, name='add'),
    path('check_in/<int:dk>/', views.check_in, name='check_in'),
    path('doc_modi/<int:dk>/', views.doc_modify, name='doc_modi'),
    path('add_rsv/<int:dk>/', views.add_rsv, name='add_rsv'),
    path('remove_doc/<int:dk>/', views.remove_doc, name='remove'),
    
    #tablet
    path('tab_login/', views.tab_login, name="tab_login"), 
    path('tab_user_select/', views.tab_user_select, name='tab_user_select'), 
    path('tab_user_addrsv/', views.tab_user_addrsv, name='tab_user_addrsv'), 
    path('tab_nonuser_addrsv/', views.tab_nonuser_addrsv, name='tab_nonuser_addrsv'), 
    path('tab_qr/', views.tab_qr, name='tab_qr'),
    
    # 비동기용
    path('doctor/', views.get_doctors, name='get_doctors'),
    path('reservation/', views.get_reservations, name='get_reservation'),
    path('rsv_len/',views.rsv_len, name='get_rsv_len'),
]


from django.contrib import admin
from .models import *
admin.site.register(Staff)
admin.site.register(Users)
admin.site.register(Doctor)
admin.site.register(Reservation)
admin.site.register(Department)
admin.site.register(M2E)
admin.site.register(Alarm)
admin.site.register(Children)
admin.site.register(Hospital_List)
admin.site.register(Reservation_non)
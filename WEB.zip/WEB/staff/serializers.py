from django.contrib.auth import authenticate 
from rest_framework import serializers
from .models import *

class UserSerializer(serializers.ModelSerializer):
    class Meta :
        model = Users
        fields = '__all__'
        

class HosiptialSerializer(serializers.ModelSerializer) :
    class Meta :
        model = Hospital_List
        fields = '__all__'

class DoctorSerializer(serializers.ModelSerializer) :
    class Meta :
        model = Doctor
        fields='__all__'
        
        
class ReservationSerializer(serializers.ModelSerializer) :
    class Meta :
        model = Reservation
        fields ='__all__'
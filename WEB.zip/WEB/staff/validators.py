import string
from django.core.exceptions import ValidationError

# 특수 문자 점검
def contains_special_character(value) :
    for char in value :
        if char in string.punctuation :
            return True
    return False

# 대문자 점검
def contains_uppercase_letter(value) :
    for char in value :
        if char.isupper() :
            return True
    return False

# 소문자 점검
def contains_lowercase_letter(value) :
    for char in value :
        if char.islower() :
            return True
    return False
 
# 숫자 점검       
def contains_number(value) :
    for char in value :
        if char.isdigit() :
            return True
    return False
        
# 비밀번호 유효성 검사
def validate(password) :
    if(
        len(password) <8 or
        not contains_uppercase_letter(password) or
        not contains_lowercase_letter(password) or
        not contains_number(password) or
        not contains_special_character(password)  
    ) : return True
    
    return False
            
from .models import *
import qrcode
from .serializers import *
import json

# 이상 접근 차단 - 세션 체크
def checked_tab_user(request) :
    user_tab = request.session.get('tab_staff')  
    user_web = request.session.get('user')
    
    if user_web :
        del(request.session['user'])
        
    if not user_tab :
        return True
    
    return False

# 의사별 대기숫자 반환 
def checked_waiting(request) :
    user_tab = request.session.get('tab_staff') 
    hospital_pk = Staff.objects.get(Staff_ID = user_tab).Hospital_ID 
    doctor_list= list(Doctor.objects.filter(Hospital_ID = hospital_pk.Hospital_ID, doctor_status=True)) 
    
    data = []
    
    if not hospital_pk.hospital_status :
        return data
    
    for i in doctor_list :
        reservation_list_user = list(Reservation.objects.filter(Doctor_ID = i.Doctor_ID, reservation_status = 'waiting')) 
        reservation_list_non_user = list(Reservation_non.objects.filter(Doctor_ID = i.Doctor_ID, reservation_status = 'waiting'))
        rsv = reservation_list_user+reservation_list_non_user
        data.append((i, len(rsv)))
        
    return data

# qr코드 생성
def make_qr(request, dk) :
    user_tab = request.session.get('tab_staff')  
    hospital_data = Staff.objects.get(Staff_ID = user_tab).Hospital_ID
    doc_data = Doctor.objects.get(Doctor_ID = dk)
    
    doc_data = DoctorSerializer(doc_data)
    data = dict()
    data['doc']  = doc_data.data
    
    qr_img = qrcode.make(json.dumps(data))
    qr_img.save('static/qrcode/qrcode.jpg')
    
    return True
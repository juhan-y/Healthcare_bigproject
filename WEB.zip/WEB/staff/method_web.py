from django.contrib import messages
from .validators import *
from .models import *
from firebase_admin import messaging, auth

# 세션 체크
def check_user_pk(request) :
    user_pk = request.session.get('user')
    if not user_pk :
        return True
    else :
        return False
    
# 패스워드 점검    
def checked_password(request, pwd, modi_pwd, re_pwd) :
    if not(re_pwd and modi_pwd and pwd ) :
        messages.error(request, 'A blank exists. Please enter all of them.') 
        return True    
        
    if modi_pwd == pwd :
        messages.error(request, 'The password you want to replace is the same as the current password.')
        return True  
        
    if validate(modi_pwd) :
        messages.error(request, 'Password format is not valid.')
        return True  
        
    if re_pwd != modi_pwd : # 비밀번호 확인 체크
        messages.error(request, 'Confirmation password does not match.') 
        return True
    
    user_pk = request.session.get('user')
    sf = Staff.objects.get(Staff_ID = user_pk)    
    
    if sf.staff_pwd != pwd : # 비밀번호 일치 여부 체크
        messages.error(request, 'The current password is not valid.') 
        return True
    
    sf.staff_pwd = modi_pwd
    sf.save()
    
    return False

# 의사별 예약내역 반환
def checked_rsv_detail(request, dk) :
    doc= Doctor.objects.get(Doctor_ID = dk) 
    rsv_user = list(Reservation.objects.filter(Doctor_ID = doc.Doctor_ID, reservation_status = 'waiting')) 
    rsv_non_user = list(Reservation_non.objects.filter(Doctor_ID = doc.Doctor_ID, reservation_status = 'waiting'))
    rsv = rsv_user+rsv_non_user
    rsv =  sorted(rsv, key=lambda x : x.reservation_date)
    
    res_data = dict()
    res_data['doc_data'] = doc
    res_data['data'] = rsv
    return res_data

# 병원 소속 의사 데이터 반환
def checked_doc(request) :
    user_pk = request.session.get('user') 
    hospital_pk = Staff.objects.get(Staff_ID = user_pk).Hospital_ID.Hospital_ID 
    doctor_list= list(Doctor.objects.filter(Hospital_ID = hospital_pk))
    return doctor_list

# 진료과 반환
def checked_dept(requset) :
    dept_list = list(Department.objects.filter())
    return dept_list

#FCM
def send_to_firebase_cloud_messaging(token, title, body):
    registration_token = token
    message = messaging.Message(
        notification=messaging.Notification(
            title=title,
            body=body,
        ),
        token=registration_token,
    )
    try:
        response = messaging.send(message)
        print(f"Successfully sent message: {response}")
    except Exception as e:
        print("예외가 발생했습니다.", e)
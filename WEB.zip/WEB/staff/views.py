from django.shortcuts import render, redirect
from .models import *
from datetime import datetime
from django.contrib import messages
from .method_web import *
from .method_tab import *

from rest_framework.decorators import api_view, authentication_classes
from rest_framework.response import Response
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from .validators import *
 
### WEB ###
 
# 기본 기능 1 : 로그인
def login(request) :
        if request.method=='GET' : 
            user_pk = request.session.get('user')  
            acc = request.session.get('acc')
            res_data = {}
            
            if acc: # 계정 저장 여부
                res_data['acc'] = acc
                res_data['ck'] = 'checked'
                    
            if user_pk : # 세션 점검(자동 로그인)
                return redirect('table/')
            
            return render(request, 'login.html',res_data)
        
        elif request.method=='POST' : 
            staff_account = request.POST.get('account') 
            staff_pwd = request.POST.get('password') 
            rm = request.POST.get('remember') # 아이디를 기억할 것인지 여부
            acc = request.session.get('acc') 
            
            res_data = dict()
            
            if not (staff_account and staff_pwd) : # 로그인 에러1 : 빈칸이 존재할 경우
                messages.error(request, 'Please fill in all the blanks.')
            else :
                sf = Staff.objects.filter(staff_account = staff_account) 
                
                if not sf : # 로그인 에러2 : DB에 알맞는 아이디가 존재하지 않을 경우
                    messages.error(request, 'This ID does not exist.')
                    return render(request, 'login.html', res_data)
                else : 
                    sf = Staff.objects.get(staff_account = staff_account)
                
                if sf.staff_pwd == staff_pwd : # 로그인 성공
                    request.session['user'] = sf.Staff_ID
                    if rm =='on' : # 아이디 기억하기 관련 설정
                        request.session['acc'] = staff_account 
                    elif (not rm) and acc : 
                        del(request.session['acc'])
                    
                    messages.info(request, 'Login Successful')
                    return redirect('/') 
                else : #로그인 에러3 : 패스워드가 알맞지 않을 경우
                    res_data['acc'] = staff_account # 비밀번호만 틀렸을 떄 계정 저장용
                    messages.error(request, 'Password is not valid.')
                    
            return render(request, 'login.html', res_data)

# 기본 기능 2 : 로그아웃
def logout(request) :
    user_pk = request.session.get('user') 
    rsv_len = request.session.get('rsv') 
    
    # 세션 정보 전부 삭제
    if user_pk :
        del(request.session['user'])
    if rsv_len :
        del(request.session['rsv'])
    messages.info(request, 'Logout completed.')
    return redirect('/')

# 기본 기능 3 : 비밀번호 변경
def modify_member_info(request) :
    
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/') # 로그인 페이지로
    
    if request.method=='GET' : 
        return render(request, 'modify.html')
    
    elif request.method=='POST' : 

        pwd = request.POST.get('password')
        modi_pwd = request.POST.get('modi_password')  
        re_pwd = request.POST.get('re_password')
        
        if checked_password(request, pwd, modi_pwd, re_pwd) : # 비밀번호 유효성 체크.
            return render(request, 'modify.html')

        if rsv_len :
            del(request.session['rsv'])
        del(request.session['user'])
        messages.info(request, 'Password has been changed. Please log in again.')
        return redirect('/') # 세션 제거 후 재로그인

# 페이지 1 : 의사별 예약 페이지
def table_detail(request,dk) :
    
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    res_data = checked_rsv_detail(request, dk) # 의사 정보 + 해당 의사 예약 정보
    return render(request, 'table_detail.html',res_data)
    
# 페이지 2 : 병원 별 예약 페이지
def table_all(request) :
    user_pk = request.session.get('user') 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
            return redirect('/')
    doctors=[]

    hospital = Staff.objects.get(Staff_ID = user_pk).Hospital_ID
    
    if not hospital.hospital_status : # 병원 상태가 off일 경우 
        return render(request, 'table_all.html', {'doctors': doctors, 'hospital': hospital})
    
    doctors= list( # 병원 소속, 진료중인 의사 리스트
        Doctor.objects
        .filter(Hospital_ID=hospital.Hospital_ID, doctor_status=True)
        .values('Doctor_ID', 'doctor_name')
    )
    ip = request.get_host() # 현재 호스트 ip 추출(ajax용)

    return render(request, 'table_all.html',{'doctors': doctors, 'hospital': hospital, 'ip':ip})

# 페이지 3-1 : 예약 상세 페이지(병원 페이지 -> 상세페이지)
def detail(request, rsv_id) :
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    res_data  = dict()
    rsv = Reservation.objects.get(Reservation_ID = rsv_id)
    res_data['data'] = rsv    
    
    if request.method=='GET' :
        return render(request, 'detail.html',res_data)
    
    elif request.method=='POST' : # 호출 메세지용
        content = request.POST.get('content')
        msg = Alarm(Reservation_ID = Reservation.objects.get(Reservation_ID=rsv_id),
            alarm_content = content,
            alarm_date = datetime.now()
        )
        msg.save()
        title = 'Announcement'
        body = content
        send_to_firebase_cloud_messaging('', title, body)
        messages.info(request, 'The transfer has been completed.')
        return render(request, 'detail.html',res_data)

# 페이지 3-2 : 예약 상세 페이지(의사 페이지 -> 상세페이지) 
def detail_2(request, dk, rsv_id) :
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    res_data  = dict()
    rsv = Reservation.objects.get(Reservation_ID = rsv_id)
    res_data['data'] = rsv  
    res_data['dk'] = dk 
   
    if request.method=='GET' :
        return render(request, 'detail.html',res_data )
    elif request.method=='POST' : # 호출 메세지용
        content = request.POST.get('content')
        msg = Alarm(Reservation_ID = Reservation.objects.get(Reservation_ID=rsv_id),
            alarm_content = content,
            alarm_date = datetime.now()
        )
        msg.save()
        title = 'Announcement'
        body = content
        send_to_firebase_cloud_messaging('', title, body)
        messages.info(request, 'The transfer has been completed.')
    
        return render(request, 'detail.html',res_data)

# 페이지 4-1 : 비회원 상세 페이지(병원 페이지 -> 상세 페이지) 
def detail_non(request, rsv_id) :
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    res_data  = dict()
    rsv = Reservation_non.objects.get(Reservation_ID = rsv_id)
    res_data['data'] = rsv    

    if request.method=='GET' :
        return render(request, 'detail.html',res_data )
    elif request.method=='POST' :
        pass

# 페이지 4-2 : 비회원 상세 페이지(의사 페이지 -> 상세 페이지) 
def detail_non_2(request, dk, rsv_id) :
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    res_data  = dict()
    rsv = Reservation_non.objects.get(Reservation_ID = rsv_id)
    res_data['data'] = rsv    
    res_data['dk'] = dk
    
    if request.method=='GET' :
        return render(request, 'detail.html',res_data )
    elif request.method=='POST' : 
        pass

# 메인 기능 1-1 : 회원 예약 취소 기능
def cancel(request, rsv_id) : 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    rsv = Reservation.objects.get(Reservation_ID = rsv_id)
    rsv.reservation_status = 'cancel'
    rsv.save()
    messages.info(request, 'The cancel is complete.')
    return redirect('/table')

# 메인 기능 1-2 : 비회원 예약 취소 기능
def cancel_non(request, rsv_id) : 
    if check_user_pk(request) :# 세션 없이 접근시(비정상적 접근)
        return redirect('/') 
    rsv = Reservation_non.objects.get(Reservation_ID = rsv_id)
    rsv.reservation_status = 'cancel'
    rsv.save()
    messages.info(request, 'The cancel is complete.')
    return redirect('/table')

# 메인 기능 2-1 : 에약 갱신(병원 페이지)
def update(request, dk) : # 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
        
    res_data = dict()
    
    data = checked_rsv_detail(request, dk)
    rsv = data['data']
    
    if rsv == [] : # 예약이 존재하지 않을 경우
        messages.error(request, 'Reservation does not exist')
        return redirect('/table')
    
    # if len(rsv)>=4 and type(rsv[3]) == Reservation : # 3번째 순번 고객에게 알림 발송
    #     msg = Alarm(Reservation_ID = rsv[3],
    #             alarm_content = 'There are three people left in front. Please wait at the hospital.',
    #             alarm_date = datetime.now()
    #     )
    #     msg.save() 
    
    rsv = rsv[0]
    rsv.reservation_status = 'comp' # 최상단 예약 갱신
    rsv.save()

    rsv_len = request.session.get('rsv')
    if rsv_len : # 예약 길이 갱신
        request.session['rsv'] = rsv_len - 1
    messages.info(request, 'The call is complete.')
    return redirect('/table')

# 메인 기능 2-2 : 예약 갱신(의사 페이지)
def update_2(request, dk) : # 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
        
    res_data = dict()
    data = checked_rsv_detail(request, dk)
    rsv = data['data']
    
    if rsv == [] :
        messages.error(request, 'Reservation does not exist')
        return redirect('/table/'+str(dk))
    
    rsv = rsv[0]
    rsv.reservation_status = 'comp'
    rsv.save()
    
    rsv_len = request.session.get('rsv')
    if rsv_len : # 예약 길이 갱신
        request.session['rsv'] = rsv_len - 1
        
    messages.info(request, 'The call is complete.')
    return redirect('/table/'+str(dk))

# 메인 기능 3 : 병원 상태 변경
def start(request) :
    user_pk = request.session.get('user') 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    hospital_pk = Staff.objects.get(Staff_ID = user_pk).Hospital_ID
    if hospital_pk.hospital_status :
        hospital_pk.hospital_status = False
    else :
        hospital_pk.hospital_status = True
    hospital_pk.save()
    
    return redirect('/table')
    
# 페이지 5 : 병원 관리 페이지
def management(request) : 
    res_data = dict()
    
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    res_data['data'] = checked_doc(request)
    
    return render(request, 'management.html',res_data)

# 메인 기능 4 : 의사 추가
def add_doc(request) : 
    user_pk = request.session.get('user') 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    res_data= dict()
    res_data['dept'] = checked_dept(request) # 진료과
    
    if request.method=='GET' : 
        return render(request, 'add_doc.html', res_data)
    
    elif request.method == 'POST' : 
        name = request.POST.get('doc_name')
        content = request.POST.get('doc_content')
        gen = request.POST.get('doc_gen')
        dept = request.POST.get('dept')
        
        if not name : # 빈칸 에러
            messages.error(request, 'Name cannot be blank.') 
            return render(request, 'modi_doc.html', res_data)
        
        doc = Doctor(Hospital_ID = Staff.objects.get(Staff_ID = user_pk).Hospital_ID,
                     Dept_ID = Department.objects.get(dept_name = dept),
                     doctor_name = name,
                     doctor_content = content,
                     doctor_gender = gen,
                     doctor_status = False,
        )
        
        doc.save()
        
        return redirect('/management')
    
# 메인 기능 5 : 의사 상태 변경
def check_in(request, dk) : 
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    doc = Doctor.objects.get(Doctor_ID= dk)
    if doc.doctor_status :
        doc.doctor_status = False
    else :
        doc.doctor_status = True    
    doc.save()
    return redirect('/management')
        
# 메인 기능 6 : 의사 정보 수정
def doc_modify(request, dk) :
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    doc = Doctor.objects.get(Doctor_ID=dk)
    res_data= dict()
    res_data['data'] = doc
    res_data['dept'] = checked_dept(request)
        
    if request.method=='GET' :
        return render(request, 'modi_doc.html', res_data)
    
    elif request.method == 'POST' :
        name = request.POST.get('doc_name')
        content = request.POST.get('doc_content')
        gen = request.POST.get('doc_gen')
        dept = request.POST.get('dept')

        if not name :
            messages.error(request, 'Name cannot be blank.') 
            return render(request, 'modi_doc.html', res_data)
        doc.Dept_ID = Department.objects.get(dept_name=dept)
        doc.doctor_name = name
        doc.doctor_content = content
        doc.doctor_gender = gen

        doc.save()
        
        return redirect('/management')

# 메인 기능 7 : 현장 예약 추가
def add_rsv(request, dk) :
    if check_user_pk(request) : # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    res_data= dict()
    
    doc = Doctor.objects.get(Doctor_ID = dk)
    res_data['doc'] = doc
    
    if request.method=='GET' :
        return render(request, 'add_rsv.html', res_data)
    
    elif request.method == 'POST' :
        doc_id = request.POST.get('doc_id')
        rsv_name = request.POST.get('rsv_name')
        tel = request.POST.get('tel')
        rnn = request.POST.get('rnn')
        addr = request.POST.get('addr')
        
        if not (rsv_name and tel and rnn and addr) : # 빈칸 에러
            messages.error(request, 'A blank exists. Please enter all of them.') 
            return render(request, 'add_rsv.html', res_data)
        
        rsv_non = Reservation_non(
            Doctor_ID = Doctor.objects.get(Doctor_ID=doc_id),
            reservation_name = rsv_name,
            reservation_status = 'waiting',
            reservation_date = datetime.now(),
            user_tel = tel,
            user_rnn = rnn,
            user_addr = addr,
        )
        
        messages.info(request, 'Appointment has been added successfully')
        rsv_non.save()
        
        return redirect('/table')

# 메인 기능 8 : 의사 삭제
def remove_doc(request, dk) :
    if check_user_pk(request) :  # 세션 없이 접근시(비정상적 접근)
        return redirect('/')
    
    doc = Doctor.objects.get(Doctor_ID=dk)
    doc.delete()
    return redirect('/management')

### Tablet ###

# 페이지 1 : 로그인
def tab_login(request):
    
    if not checked_tab_user(request) : # 세션 확인.
        return redirect('/tab_user_select')
    
    if request.method=='GET' : 
        
        acc = request.session.get('acc')
        res_data = {}
            
        if acc: # 계정 저장 여부
            res_data['acc'] = acc
            res_data['ck'] = 'checked'
                    
        return render(request, 'tab_login.html',res_data) 
        
    elif request.method=='POST' :
        staff_account = request.POST.get('account') 
        staff_pwd = request.POST.get('password') 
        rm = request.POST.get('remember') 
        acc = request.session.get('acc') 
        res_data = {}
            
        if not (staff_account and staff_pwd) : #로그인 에러1 : 빈칸이 존재할 경우
            messages.error(request, 'A blank exists. Please enter all of them.')
        else :
            sf = Staff.objects.filter(staff_account = staff_account) 
                
            if not sf : # # 로그인 에러2 : DB에 일치하는 계정 없음
                messages.error(request, 'This ID does not exist.')
                return render(request, 'tab_login.html', res_data)
           
            sf = Staff.objects.get(staff_account = staff_account)
                
            if sf.staff_pwd == staff_pwd :
                request.session['tab_staff'] = sf.Staff_ID
                if rm =='on' :
                    request.session['acc'] = staff_account 
                elif (not rm) and acc :
                    del(request.session['acc']) 
                return redirect('/tab_user_select') 
            else : # 로그인 에러3 : 패스워드 불일치
                res_data['acc'] = staff_account 
                messages.error(request, 'Password is not valid.')
                    
        return render(request, 'tab_login.html', res_data)


# 페이지 2 : 접수방식 선택         
def tab_user_select(request):
    tab_user = request.session.get('tab_user')
    
    if tab_user : # 보안용 - 회원 접수 과정 벗어났을 경우
        del(request.session['tab_user'])
        
    if checked_tab_user(request) : 
            return redirect('/tab_login')
        
    if request.method=='GET' : 
        return render(request, 'tab_user_select.html')
    
    elif request.method=='POST' : # 로그아웃 기능(함부로 로그아웃 불가능하도록 비밀번호 입력해야 가능)
        staff_id = request.session.get('tab_staff')
        staff= Staff.objects.get(Staff_ID = staff_id)
        pwd = request.POST.get('password')
        if pwd != staff.staff_pwd :
            messages.error(request, 'Password is not valid.')
            return render(request, 'tab_user_select.html')
        del(request.session['tab_staff'])
        messages.info(request, 'Logout completed.')
        return redirect('/tab_login')
    
# 접수1 : 회원 접수
def tab_user_addrsv(request):
    if checked_tab_user(request) : 
        return redirect('/tab_login')
    
    res_data=dict()
    tab_user = request.session.get('tab_user') # 앱 회원 정보
    if  tab_user : # 회원 및 산하 아동 정보 받아오기
        res_data['user_id'] = Users.objects.get(User_ID = tab_user)
        res_data['children'] = Children.objects.filter(User_ID = tab_user)
    
    res_data['data'] = checked_waiting(request)
    
    if request.method=='GET' : 
        return render(request, 'tab_user_addrsv.html', res_data)
    
    elif request.method=='POST' :
        if not tab_user : # tab_user 정보가 없다면 => 우선 회원 로그인 과정
            user_account = request.POST.get('account') 
            user_pwd = request.POST.get('password') 
            
            if not (user_account and user_pwd) : # 로그인 에러1 : 빈칸 존재
                messages.error(request, 'A blank exists. Please enter all of them.')
            else :
                user = Users.objects.filter(user_account = user_account)
                if not user : # 로그인 에러2 : DB에 아이디 존재하지 않음
                    messages.error(request, 'This ID does not exist.')
                    return render(request, 'tab_user_addrsv.html', res_data)
                user = Users.objects.get(user_account = user_account)
                
                if user.user_pwd == user_pwd : 
                    request.session['tab_user'] = user.User_ID
                    return redirect('/tab_user_addrsv') 
                else : # 로그인 에러3 : 비밀번호 불일치
                    messages.error(request, 'Password is not valid.')
                        
            return render(request, 'tab_user_addrsv.html', res_data)
        
        else : # tab_user 정보가 있다면 => 로그인이 되있다면. 예약 진행
            doc_id = request.POST.get('doc_id')
            user_name = request.POST.get('user_name')
        
            rsv = Reservation(User_ID = Users.objects.get(User_ID = request.session.get('tab_user')),
                     Doctor_ID = Doctor.objects.get(Doctor_ID = doc_id),
                     reservation_name = user_name,
                     reservation_status = 'waiting',
                     reservation_date = datetime.now(),
            )
        
            rsv.save()
            del(request.session['tab_user']) # 예약 끝난후 tab_user 정보 없애기(유저 정보 보안)
            messages.info(request, "Your appointment is successful.")
            return redirect('/tab_user_select')



# 접수 2 :  비회원 접수
def tab_nonuser_addrsv(request):  
    if checked_tab_user(request) : 
        return redirect('/tab_login')

    res_data=dict()
    res_data['data'] = checked_waiting(request)
    
    if request.method=='GET' : 
        return render(request, 'tab_nonuser_addrsv.html', res_data)
    
    elif request.method=='POST' : # 비회원 정보 받아와서 예약 추가

        doc_id = request.POST.get('doc_id')
        user_name = request.POST.get('user_name')
        tel = request.POST.get('tel')
        rnn = request.POST.get('rnn')
        addr = request.POST.get('addr')

        if not (user_name and tel and rnn and addr) : # 빈칸 에러
            messages.error(request, 'A blank exists. Please enter all of them.')
            return render(request, 'tab_nonuser_addrsv.html', res_data)
        
        rsv = Reservation_non(
                Doctor_ID = Doctor.objects.get(Doctor_ID = doc_id),
                reservation_name = user_name,
                reservation_status = 'waiting',
                reservation_date = datetime.now(),
                user_tel = tel,
                user_rnn = rnn,
                user_addr = addr,
        )
        
        rsv.save()
        messages.info(request, "Your appointment is successful.")
        return redirect('/tab_user_select')

# 접수 3 : QR 접수
def tab_qr(request):
    if checked_tab_user(request) : 
        return redirect('/tab_login')

    res_data=dict()
    res_data['data'] = checked_waiting(request)
    
    if request.method=='GET' : 
        return render(request, 'tab_qr_select.html', res_data)
    
    elif request.method=='POST' :
        doc_id = request.POST.get('doc_id')
    
        if not make_qr(request, doc_id) :  # 의사정보를 바탕으로 qr 생성
            messages.error(request, 'QR code generation failed')
        else :
            messages.info(request, 'QR code generation succeeded')

        res_data['key'] = True # qr 생성 여부
        res_data['doc_id'] = int(doc_id) # 선택한 의사 정보
        return render(request, 'tab_qr_select.html', res_data)
    

### 비동기 갱신용 API ###

# 의사 리스트 
@api_view(['GET'])
def get_doctors(request, *args, **kwargs):
    request.session['hospital_idx'] = request.GET['hospital_idx']
    hospital_idx = request.GET['hospital_idx']
    doctors = Doctor.objects.filter(Hospital_ID_id=hospital_idx, doctor_status=True).values('Doctor_ID', 'doctor_name')
    return Response(data=doctors, status=200)

# 의사별 예약 내역
@api_view(['GET'])
def get_reservations(request, *args, **kwargs):
    doctor_id = request.GET['doctor_id']
    reservations = list(Reservation.objects.filter(Doctor_ID_id=doctor_id, reservation_status='waiting'))
    reservations += list(Reservation_non.objects.filter(Doctor_ID_id=doctor_id, reservation_status='waiting'))
    reservations.sort(key=lambda reserv: reserv.reservation_date)
        
    res = [
        {'reservation_name': reserv.reservation_name,
         'detail_link': f"/detail/{reserv.Reservation_ID}" if isinstance(reserv, Reservation) else f"/detail_non/{reserv.Reservation_ID}",
        'cancel_link': f"/cancel/{reserv.Reservation_ID}" if isinstance(reserv, Reservation) else f"/cancel_non/{reserv.Reservation_ID}"}
        for reserv in reservations[:10]
    ]

    return Response(data=res, status=200)

# 병원 별 신규 예약
@api_view(['GET'])
def rsv_len(request, *args, **kwargs) :
    hospital_idx = request.GET['hospital_idx']
    doctors = Doctor.objects.filter(Hospital_ID_id=hospital_idx, doctor_status=True)
   
    rsv_len = 0 # 현재 예약 길이
    for i in doctors :
       reservations = list(Reservation.objects.filter(Doctor_ID_id=i.Doctor_ID, reservation_status='waiting'))
       reservations += list(Reservation_non.objects.filter(Doctor_ID_id=i.Doctor_ID, reservation_status='waiting'))
       rsv_len+=len(reservations)
       
    rsv_num = request.session.get('rsv') # 이전 예약 길이
    res = int()
    if not rsv_num : # 이전 예약 길이가 없을 경우(첫 접속일 때)
        request.session['rsv'] = rsv_len
        rsv_num = request.session.get('rsv')
        

    if rsv_len - rsv_num <= 0 : # 신규예약이 없을 경우
        request.session['rsv'] = rsv_len
    else : # 신규예약이 존재 할경우
        request.session['rsv'] = rsv_len
        res = rsv_len - rsv_num # 신규 예약 건수
        
    if res !=0 : # 신규 예약이 존재할 경우
        return Response(data=res, status=200)
    
    return Response(status =200) # 존재하지 않을 경우 반환 데이터 X